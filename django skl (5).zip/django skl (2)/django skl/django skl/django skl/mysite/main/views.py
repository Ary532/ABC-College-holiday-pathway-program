from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from .models import Student
from .forms import StudentForm

# Create your views here.
def home(request):
    return render(request,'main/home.html')

def about(request):
    return render(request, 'main/about.html')

def courses(request):
    return render(request, 'main/courses.html')

def contact(request):
    return render(request, 'main/contact.html')

def register(request):
    if request.method =='POST':
        form= StudentForm(request.POST)
        if form.is_valid():
            email =form.cleaned_data['email']
            password =form.cleaned_data['password']
            if User.objects.filter(username=email).exists():
                return render(request,'main/register.html',{'form':form,'error':'Email already registered.'})
            user =User.objects.create_user(username=email,email=email,password=password)
            user.save()
            student=form.save(commit=False)
            student.user = user
            prices ={
                'Digital Tech': 200,
                'Robotics': 280,
                'Hard Materials': 300,
                'Material Science': 250,
                'Food Technology': 280,
                'Food Science': 150,
            }
            base_cost = prices.get(student.course, 0)
            student.total_cost = base_cost + 80 if student.shuttle_bus else base_cost
            student.save()
            login(request, user)
            return render(request, 'main/summary.html', {'student': student})
    else:
        form = StudentForm()
    return render(request, 'main/register.html', {'form': form})

def user_login(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        user = authenticate(request, username=email, password=password)
        if user is not None:
            login(request, user)
            try:
                student = Student.objects.get(user=user)
                return render(request, 'main/summary.html', {'student': student})
            except Student.DoesNotExist:
                return render(request, 'main/login.html', {'error': 'Student profile not found.'})
        else:
            return render(request, 'main/login.html', {'error': 'Invalid email or password.'})
    return render(request, 'main/login.html')
