from django.contrib import admin
from .models import Student, Registrations, CourseChoice, CourseEnrollment
# Register your models here.

@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ('name', 'user','email', 'course',)
    search_fields = ('name', 'user', 'email')
    list_filter = ('name', 'user')

@admin.register(CourseChoice)
class CourseChoiceAdmin(admin.ModelAdmin):
    list_display = ('course_name', 'course_duration', 'course_fee')
    search_fields = ('course_name',)
    list_filter = ('course_duration',)

@admin.register(CourseEnrollment)
class CourseEnrollmentAdmin(admin.ModelAdmin):
    list_display = ('registration_id', 'course_id', 'course_name', 'enrollment_date')
    search_fields = ('course_name',)
    list_filter = ('enrollment_date',)

@admin.register(Registrations)
class RegistrationsAdmin(admin.ModelAdmin):
    list_display = ('first_name', 'last_name', 'email', 'phone_number', 'transport', 'meal_preference', 'registration_date')
    search_fields = ('first_name', 'last_name', 'email', 'phone_number')
    list_filter = ('transport', 'meal_preference', 'registration_date')