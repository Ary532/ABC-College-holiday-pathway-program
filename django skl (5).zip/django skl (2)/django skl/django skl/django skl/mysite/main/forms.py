from django import forms
from .models import Student

class StudentForm(forms.ModelForm):
    email =forms.EmailField()
    password = forms.CharField(widget=forms.PasswordInput())
    class Meta:
        model=Student
        fields=['name', 'age', 'course' ,'meal_preference','shuttle_bus', 'email', 'password']
