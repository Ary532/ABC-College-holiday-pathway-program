from django.db import models
from django.contrib.auth.models import User

# Create your models here.
COURSE_OPTIONS = [
    ('Digital Tech', 'Digital Tech - $200'),
    ('Robotics', 'Robotics - $280'),
    ('Food Science', 'Food Science - $150'),
    ('Food Technology', 'Food Technology - $280'),
    ('Material Science', 'Material Science - $250'),
    ('Hard Materials', 'Hard Materials - $300'),
]

MEAL_OPTIONS = [
    ('Standard', 'Standard'),
    ('Vegetarian', 'Vegetarian'),
    ('Vegan', 'Vegan'),
]

class Student(models.Model):
    user=models.OneToOneField(User, on_delete=models.CASCADE)
    name=models.CharField(max_length=30)
    age=models.DecimalField(max_digits=2, decimal_places = 0)
    email=models.EmailField(max_length=30)
    course=models.CharField(max_length=50, choices=COURSE_OPTIONS)
    meal_preference=models.CharField(max_length=50, choices=MEAL_OPTIONS)
    shuttle_bus=models.BooleanField()
    total_cost=models.DecimalField(max_digits=6, decimal_places=2, default=0.00)
    date_registered=models.DateTimeField(auto_now_add=True)

    def _str_(self):
        return self.name

class Registrations(models.Model):
    registration_id = models.AutoField(primary_key=True)
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.EmailField()
    phone_number = models.CharField(max_length=20)
    transport = models.CharField(max_length=50, choices=[('yes', 'No'), ('no', 'Yes')], default='no')
    meal_preference = models.CharField(max_length=50,)
    registration_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.first_name} {self.last_name} - {self.email}"
    

    # add another model for course choice
class CourseChoice(models.Model):
    course_id = models.AutoField(primary_key=True)
    course_name = models.CharField(max_length=100)
    course_duration = models.CharField(max_length=50)
    course_fee = models.DecimalField(max_digits=10, decimal_places=2)
    prerequisites = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.course_name
    
class CourseEnrollment(models.Model):
    registration_id = models.ForeignKey(Registrations, on_delete=models.CASCADE)
    course_id = models.ForeignKey(CourseChoice, on_delete=models.CASCADE)
    course_name = models.CharField(max_length=100)
    enrollment_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.registration.first_name} enrolled in {self.course.course_name}"
    
